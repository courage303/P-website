
let Ticon = document.getElementById("T-icon");
Ticon.addEventListener("click",function(){
    let rightmenu = document.getElementById("right-menu");
    rightmenu.classList.toggle("open");
});